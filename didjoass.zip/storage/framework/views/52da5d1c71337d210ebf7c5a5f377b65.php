<?php $__env->startSection('page-title', 'Create Appointment'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-300 min-h-screen">
    <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">

        <!-- Header -->
        <div class="mb-6 flex items-center">
            <a href="<?php echo e(route('admin.case-orders.show', $caseOrder->co_id)); ?>"
                class="mr-4 text-gray-600 hover:text-gray-900">
                ← Back
            </a>
            <h1 class="text-3xl font-bold text-gray-800">
                Create Appointment for CASE-<?php echo e(str_pad($caseOrder->co_id, 5, '0', STR_PAD_LEFT)); ?>

            </h1>
        </div>

        <!-- Info Alert -->
        <div class="mb-6 bg-green-50 border-l-4 border-green-400 p-4">
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                            clip-rule="evenodd" />
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-green-700">
                        <strong>Pickup Completed!</strong> Now assign a technician to work on this case order.
                    </p>
                </div>
            </div>
        </div>

        <!-- Case Details -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
            <div class="p-6">
                <h3 class="text-lg font-semibold mb-4">Case Order Details</h3>
                <div class="grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <p class="text-gray-500">Patient</p>
                        <p class="font-medium"><?php echo e($caseOrder->patient->name); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">Case Type</p>
                        <p class="font-medium"><?php echo e(ucfirst($caseOrder->case_type)); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">Submission Count</p>
                        <p class="font-medium"><?php echo e($caseOrder->submission_count > 0 ? 'Revision #' .
                            ($caseOrder->submission_count + 1) : 'Initial Work'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-8">

                <form action="<?php echo e(route('admin.case-orders.store-appointment', $caseOrder->co_id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <!-- Technician Selection -->
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Assign Technician <span class="text-red-500">*</span>
                        </label>
                        <select name="technician_id" required
                            class="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500">
                            <option value="">Select Technician</option>
                            <?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($technician->id); ?>" <?php echo e(old('technician_id')==$technician->id ? 'selected'
                                : ''); ?>>
                                <?php echo e($technician->name); ?> - <?php echo e($technician->contact_number); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['technician_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Schedule DateTime -->
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Schedule Date & Time <span class="text-red-500">*</span>
                        </label>
                        <input type="datetime-local" name="estimated_date" required
                            min="<?php echo e(date('Y-m-d', strtotime('+1 hour'))); ?>" value="<?php echo e(old('estimated_date')); ?>"
                            class="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <?php $__errorArgs = ['estimated_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Purpose -->
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Purpose / Work Description
                        </label>
                        <textarea name="purpose" rows="3" placeholder="Describe the work to be done..."
                            class="w-full p-3 border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500"><?php echo e(old('purpose', $caseOrder->submission_count > 0 ? 'Revision/Adjustment Work' : 'Initial Work')); ?></textarea>
                        <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Action Buttons -->
                    <div class="flex justify-end gap-4">
                        <a href="<?php echo e(route('admin.case-orders.show', $caseOrder->co_id)); ?>"
                            class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg transition">
                            Cancel
                        </a>
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition">
                            Create Appointment
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/case-orders/create-appointment.blade.php ENDPATH**/ ?>