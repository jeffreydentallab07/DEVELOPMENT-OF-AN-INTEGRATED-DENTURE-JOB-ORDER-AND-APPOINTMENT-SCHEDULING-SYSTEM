<?php $__env->startSection('page-title', 'Create Billing'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-100 min-h-screen">
    <div class="max-w-4xl mx-auto">

        <a href="<?php echo e(route('admin.billing.index')); ?>" class="text-blue-600 hover:underline mb-4 inline-block">
            ← Back to Billings
        </a>

        <div class="bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-2xl font-bold text-gray-800 mb-6">Create New Billing</h1>

            <?php if($errors->any()): ?>
            <div class="mb-4 p-4 bg-red-100 border border-red-300 text-red-700 rounded">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.billing.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Appointment Selection -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Select Completed Appointment <span class="text-red-500">*</span>
                    </label>

                    <?php if($appointment): ?>
                    <!-- Pre-selected appointment -->
                    <div class="border-2 border-blue-500 rounded-lg p-4 bg-blue-50">
                        <div class="flex items-center justify-between mb-3">
                            <div>
                                <p class="font-semibold text-gray-800">APT-<?php echo e(str_pad($appointment->appointment_id, 5,
                                    '0', STR_PAD_LEFT)); ?></p>
                                <p class="text-sm text-gray-600">CASE-<?php echo e(str_pad($appointment->case_order_id, 5, '0',
                                    STR_PAD_LEFT)); ?></p>
                            </div>
                            <span class="px-3 py-1 bg-green-600 text-white rounded-full text-xs">Completed</span>
                        </div>
                        <div class="grid grid-cols-2 gap-3 text-sm">
                            <div>
                                <p class="text-gray-500">Clinic:</p>
                                <p class="font-medium text-gray-800"><?php echo e($appointment->caseOrder->clinic->clinic_name); ?>

                                </p>
                            </div>
                            <div>
                                <p class="text-gray-500">Patient:</p>
                                <p class="font-medium text-gray-800"><?php echo e($appointment->caseOrder->patient->name); ?></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Case Type:</p>
                                <p class="font-medium text-gray-800"><?php echo e($appointment->caseOrder->case_type); ?></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Material Cost:</p>
                                <p class="font-medium text-green-600">₱<?php echo e(number_format($appointment->total_material_cost, 2)); ?></p>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="appointment_id" value="<?php echo e($appointment->appointment_id); ?>">
                    <input type="hidden" id="materialCost" value="<?php echo e($appointment->total_material_cost); ?>">
                    <?php else: ?>
                    <!-- Dropdown selection -->
                    <select name="appointment_id" id="appointmentSelect" required
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none"
                        onchange="updateAppointmentDetails()">
                        <option value="">-- Select Completed Appointment --</option>
                        <?php $__currentLoopData = $completedAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($apt->appointment_id); ?>"
                            data-clinic="<?php echo e($apt->caseOrder->clinic->clinic_name); ?>"
                            data-patient="<?php echo e($apt->caseOrder->patient->name); ?>"
                            data-case="<?php echo e($apt->caseOrder->case_type); ?>" data-cost="<?php echo e($apt->total_material_cost); ?>">
                            APT-<?php echo e(str_pad($apt->appointment_id, 5, '0', STR_PAD_LEFT)); ?> - <?php echo e($apt->caseOrder->clinic->clinic_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <!-- Appointment Preview -->
                    <div id="appointmentPreview" class="hidden mt-3 p-4 bg-gray-50 rounded-lg border">
                        <div class="grid grid-cols-2 gap-3 text-sm">
                            <div>
                                <p class="text-gray-500">Clinic:</p>
                                <p class="font-medium text-gray-800" id="previewClinic"></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Patient:</p>
                                <p class="font-medium text-gray-800" id="previewPatient"></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Case Type:</p>
                                <p class="font-medium text-gray-800" id="previewCase"></p>
                            </div>
                            <div>
                                <p class="text-gray-500">Material Cost:</p>
                                <p class="font-medium text-green-600" id="previewCost"></p>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="materialCost" value="0">
                    <?php endif; ?>
                </div>

                <!-- Total Amount -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Total Amount <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <span class="absolute left-3 top-3 text-gray-500">₱</span>
                        <input type="number" name="total_amount" id="totalAmount" step="0.01" min="0" required
                            value="<?php echo e($appointment ? $appointment->total_material_cost : ''); ?>"
                            class="w-full border-2 border-gray-300 rounded-lg p-3 pl-8 focus:border-blue-500 focus:outline-none"
                            placeholder="0.00">
                    </div>
                    <p class="text-xs text-gray-500 mt-1">
                        Suggested: Material Cost + Labor + Other Charges
                    </p>
                </div>

                <!-- Payment Status -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Payment Status <span class="text-red-500">*</span>
                    </label>
                    <select name="payment_status" required
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none">
                        <option value="unpaid">Unpaid</option>
                        <option value="partial">Partial Payment</option>
                        <option value="paid">Paid</option>
                    </select>
                </div>

                <!-- Payment Method -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Payment Method (Optional)
                    </label>
                    <select name="payment_method"
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none">
                        <option value="">-- Select Method --</option>
                        <option value="Cash">Cash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Credit Card">Credit Card</option>
                        <option value="Debit Card">Debit Card</option>
                        <option value="GCash">GCash</option>
                        <option value="PayMaya">PayMaya</option>
                        <option value="Check">Check</option>
                    </select>
                </div>

                <!-- Notes -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Notes (Optional)
                    </label>
                    <textarea name="notes" rows="4"
                        class="w-full border-2 border-gray-300 rounded-lg p-3 focus:border-blue-500 focus:outline-none"
                        placeholder="Additional notes or payment terms..."></textarea>
                </div>

                <!-- Info Box -->
                

                <!-- Action Buttons -->
                <div class="flex justify-end gap-3 pt-4 border-t">
                    <a href="<?php echo e(route('admin.billing.index')); ?>"
                        class="px-6 py-3 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                        Cancel
                    </a>
                    <button type="submit"
                        class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold">
                        Create Billing
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function updateAppointmentDetails() {
    const select = document.getElementById('appointmentSelect');
    const option = select.options[select.selectedIndex];
    
    if (select.value) {
        document.getElementById('previewClinic').textContent = option.dataset.clinic;
        document.getElementById('previewPatient').textContent = option.dataset.patient;
        document.getElementById('previewCase').textContent = option.dataset.case;
        document.getElementById('previewCost').textContent = '₱' + parseFloat(option.dataset.cost).toLocaleString('en-US', {minimumFractionDigits: 2});
        document.getElementById('appointmentPreview').classList.remove('hidden');
        document.getElementById('materialCost').value = option.dataset.cost;
        
        // Suggest total amount based on material cost
        document.getElementById('totalAmount').value = parseFloat(option.dataset.cost).toFixed(2);
    } else {
        document.getElementById('appointmentPreview').classList.add('hidden');
        document.getElementById('totalAmount').value = '';
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/billing/create.blade.php ENDPATH**/ ?>