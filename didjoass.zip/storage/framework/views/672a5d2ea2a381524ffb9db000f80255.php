<?php $__env->startSection('title', 'Clinic Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-300 min-h-screen text-[13px] space-y-6">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Clinic Dashboard</h1>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-5">
        <div
            class="bg-white backdrop-blur-lg rounded-xl shadow-lg border border-white/80 p-5 hover:shadow-2xl hover:-translate-y-1 hover:scale-105 transition transform duration-300">
            <h6 class="text-gray-500 text-xs uppercase tracking-wider">Total Case Orders</h6>
            <h3 class="text-2xl font-bold text-[#189ab4] mt-2"><?php echo e($totalCaseOrders); ?></h3>
        </div>
        <div
            class="bg-white backdrop-blur-lg rounded-xl shadow-lg border border-white/80 p-5 hover:shadow-2xl hover:-translate-y-1 hover:scale-105 transition transform duration-300">
            <h6 class="text-gray-500 text-xs uppercase tracking-wider">Completed</h6>
            <h3 class="text-2xl font-bold text-green-600 mt-2"><?php echo e($completedCases); ?></h3>
        </div>
        <div
            class="bg-white backdrop-blur-lg rounded-xl shadow-lg border border-white/80 p-5 hover:shadow-2xl hover:-translate-y-1 hover:scale-105 transition transform duration-300">
            <h6 class="text-gray-500 text-xs uppercase tracking-wider">Pending</h6>
            <h3 class="text-2xl font-bold text-yellow-600 mt-2"><?php echo e($pendingCases); ?></h3>
        </div>
        <div
            class="bg-white backdrop-blur-lg rounded-xl shadow-lg border border-white/80 p-5 hover:shadow-2xl hover:-translate-y-1 hover:scale-105 transition transform duration-300">
            <h6 class="text-gray-500 text-xs uppercase tracking-wider">Patients</h6>
            <h3 class="text-2xl font-bold text-blue-600 mt-2"><?php echo e($totalPatients); ?></h3>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-6">
        <div class="col-span-12 lg:col-span-8 flex flex-col gap-6">
            <section
                class="bg-white backdrop-blur-lg rounded-xl shadow-lg border border-white/80 overflow-hidden flex flex-col hover:shadow-xl hover:-translate-y-1 transition transform duration-300">
                <div class="px-4 py-3 border-b border-gray-200">
                    <h6 class="font-semibold text-gray-700">Recent Appointments</h6>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-blue-900 text-white sticky top-0 shadow">
                            <tr>
                                <th class="px-4 py-2 text-left font-semibold">Patient</th>
                                <th class="px-4 py-2 text-left font-semibold">Technician</th>
                                <th class="px-4 py-2 text-left font-semibold">Date & Time</th>
                                <th class="px-4 py-2 text-center font-semibold">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 text-gray-800">
                            <?php $__empty_1 = true; $__currentLoopData = $recentAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-4 py-2"><?php echo e($appointment->caseOrder->patient->name ?? 'N/A'); ?></td>
                                <td class="px-4 py-2"><?php echo e($appointment->technician->name ?? 'Not assigned'); ?></td>
                                <td class="px-4 py-2 text-[11px] text-gray-500">
                                    <?php echo e($appointment->estimated_date->format('M d, Y')); ?>

                                </td>
                                <td class="px-4 py-2 text-center">
                                    <span class="bg-<?php echo e($appointment->work_status == 'completed' ? 'green' : 'yellow'); ?>-200 
                                                 text-<?php echo e($appointment->work_status == 'completed' ? 'green' : 'yellow'); ?>-900 
                                                 font-medium px-2 py-0.5 rounded-full text-xs">
                                        <?php echo e(ucfirst($appointment->work_status)); ?>

                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-gray-500">No appointments yet.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>

        <div class="col-span-12 lg:col-span-4">
            <div class="bg-white backdrop-blur-lg rounded-xl shadow-lg border border-white/80 p-5">
                <h6 class="font-semibold text-gray-700 mb-4">Quick Stats</h6>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Total Dentists</span>
                        <span class="font-bold text-[#189ab4]"><?php echo e($totalDentists); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Total Patients</span>
                        <span class="font-bold text-[#189ab4]"><?php echo e($totalPatients); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clinic', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/clinic/dashboard.blade.php ENDPATH**/ ?>