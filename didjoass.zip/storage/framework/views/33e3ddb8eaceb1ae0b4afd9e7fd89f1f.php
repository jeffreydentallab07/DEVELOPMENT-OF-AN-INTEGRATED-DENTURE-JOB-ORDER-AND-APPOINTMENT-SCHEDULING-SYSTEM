<?php $__env->startSection('page-title', 'Appointments'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 space-y-6 bg-gray-300 min-h-screen">

    <!-- Header with Create Button -->
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-bold text-gray-800">Appointments</h1>
        <a href="<?php echo e(route('admin.appointments.create')); ?>"
            class="bg-green-500 text-white px-5 py-2 rounded font-semibold hover:bg-green-600 transition">
            + Create Appointment
        </a>
    </div>

    <?php if(session('success')): ?>
    <div class="mb-4 p-3 rounded bg-green-100 text-green-700 border border-green-300">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <!-- Appointments Table -->
    <div class="overflow-x-auto rounded-xl shadow-lg">
        <table class="min-w-full bg-white">
            <thead>
                <tr class="bg-blue-900 text-white">
                    <th class="px-6 py-3 text-left">Appointment ID</th>
                    <th class="px-6 py-3 text-left">Case No.</th>
                    <th class="px-6 py-3 text-left">Clinic</th>
                    <th class="px-6 py-3 text-left">Patient</th>
                    <th class="px-6 py-3 text-left">Technician</th>
                    <th class="px-6 py-3 text-left">Est. Completion</th>
                    <th class="px-6 py-3 text-left">Status</th>
                    <th class="px-6 py-3 text-left">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-6 py-3 font-semibold">APT-<?php echo e(str_pad($appointment->appointment_id, 5, '0',
                        STR_PAD_LEFT)); ?></td>
                    <td class="px-6 py-3">
                        <a href="<?php echo e(route('admin.case-orders.show', $appointment->case_order_id)); ?>"
                            class="text-blue-600 hover:underline">
                            CASE-<?php echo e(str_pad($appointment->case_order_id, 5, '0', STR_PAD_LEFT)); ?>

                        </a>
                    </td>
                    <td class="px-6 py-3"><?php echo e($appointment->caseOrder->clinic->clinic_name ?? 'N/A'); ?></td>
                    <td class="px-6 py-3"><?php echo e($appointment->caseOrder->patient->name ?? 'N/A'); ?></td>
                    <td class="px-6 py-3"><?php echo e($appointment->technician->name ?? 'N/A'); ?></td>
                    <td class="px-6 py-3 text-sm"><?php echo e($appointment->estimated_date->format('M d, Y')); ?></td>
                    <td class="px-6 py-3">
                        <span
                            class="px-2 py-1 text-xs rounded-full font-medium
                        <?php echo e($appointment->work_status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                        ($appointment->work_status === 'in-progress' ? 'bg-blue-100 text-blue-800' : 
                        ($appointment->work_status === 'completed' ? 'bg-green-100 text-green-800' : 
                        ($appointment->work_status === 'cancelled' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800')))); ?>">
                            <?php echo e(ucfirst(str_replace('-', ' ', $appointment->work_status))); ?>

                        </span>
                    </td>
                    <td class="px-6 py-3">
                        <a href="<?php echo e(route('admin.appointments.show', $appointment->appointment_id)); ?>"
                            class="text-blue-600 hover:underline text-sm">
                            View Details
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center py-8 text-gray-500">No appointments found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        <?php echo e($appointments->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/appointments/index.blade.php ENDPATH**/ ?>