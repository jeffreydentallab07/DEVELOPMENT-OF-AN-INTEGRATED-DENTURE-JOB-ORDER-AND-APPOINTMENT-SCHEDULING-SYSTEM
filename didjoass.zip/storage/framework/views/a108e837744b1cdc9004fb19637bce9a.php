<?php $__env->startSection('page-title', 'Case Orders List'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 space-y-6 bg-gray-300 min-h-screen">

    <?php if(session('success')): ?>
    <div class="mb-4 p-3 rounded bg-green-100 text-green-700 border border-green-300">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="overflow-x-auto rounded-xl shadow-lg mt-4">
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr class="bg-blue-900 text-white">
                    <th class="px-6 py-3 text-left">Case No.</th>
                    <th class="px-6 py-3 text-left">Clinic</th>
                    <th class="px-6 py-3 text-left">Patient</th>
                    <th class="px-6 py-3 text-left">Dentist</th>
                    <th class="px-6 py-3 text-left">Case Type</th>
                    <th class="px-6 py-3 text-left">Status</th>
                    <th class="px-6 py-3 text-left">Created</th>
                    <th class="px-6 py-3 text-center">Action</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $caseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="text-gray-700 text-sm hover:bg-gray-50">
                    <td class="px-6 py-3">
                        <a href="<?php echo e(route('admin.case-orders.show', $caseOrder->co_id)); ?>"
                            class="text-blue-600 hover:underline font-semibold">
                            <?php echo e('CASE-' . str_pad($caseOrder->co_id, 5, '0', STR_PAD_LEFT)); ?>

                        </a>
                    </td>
                    <td class="px-6 py-3"><?php echo e($caseOrder->clinic->clinic_name ?? 'N/A'); ?></td>
                    <td class="px-6 py-3"><?php echo e($caseOrder->patient->name ?? 'N/A'); ?></td>
                    <td class="px-6 py-3">
                        <?php echo e($caseOrder->dentist ? 'Dr. ' . $caseOrder->dentist->name : 'N/A'); ?>

                    </td>
                    <td class="px-6 py-3"><?php echo e($caseOrder->case_type); ?></td>
                    <td class="px-6 py-3">
                        <?php
                        $statusColors = [
                        'pending' => 'bg-gray-100 text-gray-800', 'for appointment' => 'bg-blue-50 text-blue-700',
                        'in progress' => 'bg-blue-100 text-blue-800',
                        'under review' => 'bg-purple-100 text-purple-800',
                        'adjustment requested' => 'bg-orange-100 text-orange-800',
                        'revision in progress' => 'bg-yellow-100 text-yellow-800',
                        'completed' => 'bg-green-100 text-green-800',
                        ];
                        ?>

                        <span
                            class="px-3 py-1 rounded-full text-xs font-semibold <?php echo e($statusColors[$caseOrder->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                            <?php echo e(ucfirst($caseOrder->status)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-3 text-xs text-gray-500">
                        <?php echo e($caseOrder->created_at->format('M d, Y')); ?>

                    </td>
                    <td class="px-6 py-3 text-center">
                        <a href="<?php echo e(route('admin.case-orders.show', $caseOrder->co_id)); ?>"
                            class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 transition text-xs">
                            View Details
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center py-8 text-gray-500">No case orders found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        <?php echo e($caseOrders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/admin/case-orders/index.blade.php ENDPATH**/ ?>