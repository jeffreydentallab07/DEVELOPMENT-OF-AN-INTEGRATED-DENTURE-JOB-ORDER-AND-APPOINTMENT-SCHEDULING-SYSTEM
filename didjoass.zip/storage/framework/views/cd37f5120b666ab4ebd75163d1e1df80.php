<?php $__env->startSection('title', 'My Appointments'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-100 min-h-screen">
    <div class="max-w-7xl mx-auto">

        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-800">My Appointments</h1>
            <p class="text-gray-600">All your assigned appointments</p>
        </div>

        <!-- Filter Tabs -->
        <div class="bg-white rounded-lg shadow mb-6">
            <div class="flex border-b">
                <button onclick="filterAppointments('all')"
                    class="filter-tab px-6 py-3 font-medium text-gray-600 hover:text-blue-600 border-b-2 border-transparent hover:border-blue-600 active">
                    All
                </button>
                <button onclick="filterAppointments('pending')"
                    class="filter-tab px-6 py-3 font-medium text-gray-600 hover:text-blue-600 border-b-2 border-transparent hover:border-blue-600">
                    Pending
                </button>
                <button onclick="filterAppointments('in-progress')"
                    class="filter-tab px-6 py-3 font-medium text-gray-600 hover:text-blue-600 border-b-2 border-transparent hover:border-blue-600">
                    In Progress
                </button>
                <button onclick="filterAppointments('completed')"
                    class="filter-tab px-6 py-3 font-medium text-gray-600 hover:text-blue-600 border-b-2 border-transparent hover:border-blue-600">
                    Completed
                </button>
            </div>
        </div>

        <!-- Appointments Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="appointment-card bg-white rounded-lg shadow hover:shadow-lg transition"
                data-status="<?php echo e($appointment->work_status); ?>">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <p class="text-xs text-gray-500">Appointment #</p>
                            <p class="text-lg font-bold text-gray-800">APT-<?php echo e(str_pad($appointment->appointment_id, 5,
                                '0', STR_PAD_LEFT)); ?></p>
                        </div>
                        <span
                            class="px-2 py-1 text-xs rounded-full font-medium
                            <?php echo e($appointment->work_status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                               ($appointment->work_status === 'in-progress' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800')); ?>">
                            <?php echo e(ucfirst(str_replace('-', ' ', $appointment->work_status))); ?>

                        </span>
                    </div>

                    <div class="space-y-2 mb-4">
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4">
                                </path>
                            </svg>
                            <p class="text-sm text-gray-700"><?php echo e($appointment->caseOrder->clinic->clinic_name); ?></p>
                        </div>
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                                </path>
                            </svg>
                            <p class="text-sm text-gray-700"><?php echo e($appointment->caseOrder->case_type); ?></p>
                        </div>
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                </path>
                            </svg>
                            <p class="text-sm text-gray-700"><?php echo e($appointment->schedule_datetime->format('M d, Y h:i A')); ?></p>
                        </div>
                    </div>

                    <div class="border-t pt-4 flex justify-between items-center">
                        <p class="text-xs text-gray-500"><?php echo e($appointment->materialUsages->count()); ?> material(s) used
                        </p>
                        <a href="<?php echo e(route('technician.appointments.show', $appointment->appointment_id)); ?>"
                            class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                            View Details →
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-3 text-center py-12">
                <svg class="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                    </path>
                </svg>
                <p class="text-gray-500">No appointments found</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    function filterAppointments(status) {
    const cards = document.querySelectorAll('.appointment-card');
    const tabs = document.querySelectorAll('.filter-tab');
    
    // Update tab styles
    tabs.forEach(tab => {
        tab.classList.remove('border-blue-600', 'text-blue-600');
        tab.classList.add('border-transparent', 'text-gray-600');
    });
    event.target.classList.add('border-blue-600', 'text-blue-600');
    event.target.classList.remove('border-transparent', 'text-gray-600');
    
    // Filter cards
    cards.forEach(card => {
        if (status === 'all' || card.dataset.status === status) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.technician', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ᴄᴛOS\Desktop\CAPSTONE\denture-lab-system\resources\views/technician/appointments/index.blade.php ENDPATH**/ ?>